from django.apps import AppConfig


class django_cronConfig(AppConfig):
    name = 'django_cron'
