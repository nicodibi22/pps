//HomeController
(function () {
  'use strict';

  angular
    .module('django-angular.home.controllers')
    .controller('HomeController', [ '$scope', 'Home', function($scope, Home) {

		/*Home.bleu_score("some input", "some output").then(getBleuScoreSuccessFn, getBleuScoreErrorFn);

		function getBleuScoreSuccessFn(data, status, headers, config) {
			$scope.bleu_score = data.data;
		}

		function getBleuScoreErrorFn(data, status, headers, config) {
			console.log(data.data);
		}*/

    }]);
})();
