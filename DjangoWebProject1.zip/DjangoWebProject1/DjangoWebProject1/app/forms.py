"""
Definition of forms.
"""

from django import forms
from django.contrib.auth.forms import AuthenticationForm
from django.utils.translation import ugettext_lazy as _
from app.models import Usuario

class BootstrapAuthenticationForm(AuthenticationForm):
    """Authentication form which uses boostrap CSS."""
    username = forms.CharField(max_length=254,
                               label=_("Usuario"),
                               widget=forms.TextInput({
                                   'class': 'form-control',
                                   'placeholder': 'Nombre de Usuario'}))
    password = forms.CharField(label=_("Password"),
                               widget=forms.PasswordInput({
                                   'class': 'form-control',
                                   'placeholder':'Password'}))

class RegisterUserForm(forms.ModelForm):

        class Meta:
            model = Usuario
            fields = ('first_name', 'last_name', 'username','password', 'email')
            help_texts = {
                'username': None,
            }