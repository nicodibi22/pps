from app.models import *
from app.forms import *

def get_administrador()
	