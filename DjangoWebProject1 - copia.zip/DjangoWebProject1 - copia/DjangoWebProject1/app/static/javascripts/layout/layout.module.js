(function () {
    'use strict';

    angular
        .module('django-angular.layout', [
            'django-angular.layout.controllers'
        ]);

    angular
        .module('django-angular.layout.controllers', []);
})();
